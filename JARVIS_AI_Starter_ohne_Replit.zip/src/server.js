require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database(path.join(__dirname, "jarvis.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 credits INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS usage_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 feature TEXT NOT NULL,
 credits INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "2mb" }));
app.use(session({
 secret: process.env.SESSION_SECRET || "development-only-change-this",
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));
app.use(express.static(path.join(__dirname, "..", "public")));

const ownerEmail = (process.env.OWNER_EMAIL || "").toLowerCase().trim();
const ownerPassword = process.env.OWNER_PASSWORD || "";
if (ownerEmail && ownerPassword && !db.prepare("SELECT id FROM users WHERE email=?").get(ownerEmail)) {
  const hash = bcrypt.hashSync(ownerPassword, 12);
  db.prepare("INSERT INTO users(email,password_hash,role,credits) VALUES(?,?,?,?)")
    .run(ownerEmail, hash, "admin", 999999);
}

function auth(req,res,next) {
  if (!req.session.user) return res.status(401).json({error:"Bitte zuerst anmelden."});
  next();
}
function admin(req,res,next) {
  if (req.session.user?.role !== "admin") return res.status(403).json({error:"Nur für Admins."});
  next();
}

app.post("/api/register", (req,res) => {
  const email = String(req.body.email || "").toLowerCase().trim();
  const password = String(req.body.password || "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10)
    return res.status(400).json({error:"Gültige E-Mail und Passwort mit mindestens 10 Zeichen erforderlich."});
  try {
    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare("INSERT INTO users(email,password_hash,role,credits) VALUES(?,?,?,?)")
      .run(email, hash, "user", 0);
    req.session.user = {id:Number(result.lastInsertRowid), email, role:"user", credits:0};
    res.json({user:req.session.user});
  } catch { res.status(409).json({error:"Diese E-Mail ist bereits registriert."}); }
});
app.post("/api/login", (req,res) => {
  const email = String(req.body.email || "").toLowerCase().trim();
  const row = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!row || !bcrypt.compareSync(String(req.body.password || ""), row.password_hash))
    return res.status(401).json({error:"E-Mail oder Passwort falsch."});
  req.session.user = {id:row.id,email:row.email,role:row.role,credits:row.credits};
  res.json({user:req.session.user});
});
app.post("/api/logout", (req,res) => req.session.destroy(() => res.json({ok:true})));
app.get("/api/me", (req,res) => res.json({user:req.session.user || null}));
app.get("/api/admin/overview", auth, admin, (req,res) => {
  const users = db.prepare("SELECT id,email,role,credits,created_at FROM users ORDER BY id DESC").all();
  const usage = db.prepare("SELECT feature, SUM(credits) AS credits, COUNT(*) AS jobs FROM usage_log GROUP BY feature").all();
  res.json({users,usage});
});
// Placeholder endpoint: provider adapter and server-side billing must be configured before real generation.
app.post("/api/generate", auth, (req,res) => {
  const feature = String(req.body.feature || "");
  const prompt = String(req.body.prompt || "").trim();
  const allowed = ["chat","image","video","image-to-video","document"];
  if (!allowed.includes(feature) || !prompt) return res.status(400).json({error:"Ungültige Anfrage."});
  if (req.session.user.role !== "admin")
    return res.status(503).json({error:"KI-Anbieter noch nicht verbunden. Generierung wird erst nach Einrichtung eines Providers und der Abrechnung aktiviert."});
  res.status(503).json({error:"Admin-Freigabe ist kostenlos; der KI-Dienst muss trotzdem serverseitig verbunden werden."});
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JARVIS AI läuft auf http://localhost:${port}`));
