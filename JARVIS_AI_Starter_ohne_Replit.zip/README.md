# JARVIS AI – Starter 0.1

## Enthalten
- Responsive JARVIS-Oberfläche für Handy und PC
- Registrierung und Login mit Passwort-Hashing
- Rollenmodell: `admin` (Owner) und `user`
- Admin-Konto wird beim ersten Start aus `OWNER_EMAIL` / `OWNER_PASSWORD` angelegt
- Admin-Gebührenbefreiung ist als Rollenlogik vorbereitet
- Admin-API für Nutzerübersicht und Nutzungsstatistik
- KI-Generierung ist bewusst deaktiviert, bis Provider und sichere Abrechnung eingerichtet sind

## Lokal starten
1. Node.js 20+ installieren
2. `npm install`
3. `.env.example` nach `.env` kopieren
4. `OWNER_EMAIL`, `OWNER_PASSWORD` (mindestens 10 Zeichen) und `SESSION_SECRET` setzen
5. `npm start`
6. Browser: http://localhost:3000

## Vor einem öffentlichen Launch zwingend erledigen
- HTTPS, sichere Session-/Cookie-Konfiguration und produktiver Session-Store
- E-Mail-Verifizierung, Passwort-Reset, Rate-Limits, CSRF-Schutz und Audit-Logs
- DSGVO-konforme Datenschutzerklärung, Impressum, AGB, Widerruf und Lösch-/Exportprozesse
- Stripe Checkout + Webhooks + serverseitige Credit-Buchungen und Erstattungen
- Provider-Adapter für Chat, Bild, Video, Speech-to-Text und Text-to-Speech
- Kostenlimits, Missbrauchsschutz, Job-Queue und Storage
- Admin-Identität sicher verifizieren; Admin-Konto nicht über öffentliches Signup vergeben

**Status:** Entwicklungsstarter, kein bereits gehosteter oder produktionsreifer Dienst. Noch keine echte KI-Generierung und keine echten Zahlungen.
